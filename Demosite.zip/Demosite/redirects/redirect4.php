<?php
	Header("Location: http://83.169.37.29/frick/Demosite/redirects/redirect3.php");
?>